package testCases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class Tc_CrmSfa_002 extends ProjectSpecificMethod {
	
	@BeforeTest
	public void setValues() {
		fileName = "CreateLead";
	}

	// STEP E3;
	@Test(dataProvider = "getValue")
	public void runCrmSfa(String uName, String pWord) throws InterruptedException {
		LoginPage logOut = new LoginPage();
		logOut.EnterUserName(uName).EnterPassWord(pWord).ClickLoginButton().ClickCrmSfa();
	}

}
