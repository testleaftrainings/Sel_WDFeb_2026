package testCases;

import base.ProjectSpecificMethod;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features = "src/main/java/features/Login.feature", glue = "pages", publish = true)
public class RunnerClass extends ProjectSpecificMethod {

}
