package testCases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class Tc_LogOut_001 extends ProjectSpecificMethod {
	
	@BeforeTest
	public void setValues() {
		fileName = "CreateLead";
	}
	
	//STEP E3;
	@Test(dataProvider = "getValue")
	public void runLogin(String uName, String pWord) throws InterruptedException {
		LoginPage lp = new LoginPage();
		lp.EnterUserName(uName).EnterPassWord(pWord).ClickLoginButton();
		
	}

}
