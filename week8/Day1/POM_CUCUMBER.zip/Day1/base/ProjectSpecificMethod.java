package base;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadValue;

//STEP 6: - ProjectSpecificMethod extends AbstractTestNGCucumberTest
//		  - RunnerClass extends ProjectSpecificMethod
public class ProjectSpecificMethod extends AbstractTestNGCucumberTests {

	// STEP 1: HYBRID -Remove
//	public ChromeDriver driver;

	// STEP 2: Declare the ThreadLocal as private static final
	private static final ThreadLocal<RemoteWebDriver> cDriver = new ThreadLocal<RemoteWebDriver>();

	// STEP 3: - Set the driver
	public void setDriver() {
		cDriver.set(new ChromeDriver());
	}

	// STEP 4: - get the driver
	public RemoteWebDriver getDriver() {
		return cDriver.get();
	}

	public String fileName;

	@BeforeMethod
	public void preCondition() {
		/*
		 * ChromeOptions options = new ChromeOptions(); options.addArguments("--guest");
		 * driver = new ChromeDriver(options);
		 */
		// STEP 5- setDriver & getDriver;
		setDriver();

		getDriver().manage().window().maximize();
		getDriver().get("http://leaftaps.com/opentaps/control/main");
		System.out.println("Driver Value ");
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}

	@AfterMethod
	public void postConditions() {
		getDriver().close();
	}

	// STEP E2;
	@DataProvider(name = "getValue")
	public String[][] fetchData() throws IOException {
		return ReadValue.getValue(fileName);
	}

}
