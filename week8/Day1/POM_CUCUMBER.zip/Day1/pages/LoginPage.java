package pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.When;

public class LoginPage extends ProjectSpecificMethod {

	// 1.Enter userName
	// 2.Enter PassWord
	// 3.Click on Login Button

	// STEP 2: Create a parameterized constructor - Parallel

	/*
	 * // public LoginPage(ChromegetDriver() getDriver()) { // this.getDriver() =
	 * getDriver(); // }
	 */

	@When(": enter the userName {string}")
	public LoginPage EnterUserName(String uName) throws InterruptedException {
		getDriver().findElement(By.id("username")).sendKeys(uName);
		return this;
	}

	@When(": enter the password {string}")
	public LoginPage EnterPassWord(String pWord) {
		getDriver().findElement(By.id("password")).sendKeys(pWord);
		return this;
	}

	@When(": click on the login button")
	public HomePage ClickLoginButton() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
		return new HomePage();
	}
}
