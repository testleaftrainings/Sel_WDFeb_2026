package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.Then;

public class HomePage extends ProjectSpecificMethod {

	// 1.Click on CRM/SFA
	// 2.Click on Logout

	// STEP 2: Create a parameterized constructor - Parallel

	/*
	 * public HomePage(ChromeDriver driver) { this.driver = driver; }
	 */

	/*
	 * public HomePage ClickLogOut() {
	 * driver.findElement(By.className("decorativeSubmit")).click(); return this; }
	 */

	@Then(": it will navigate to the crm\\/sfa page")
	public MyHomePage ClickCrmSfa() {
		getDriver().findElement(By.linkText("CRM/SFA")).click();
		return new MyHomePage();
	}

}
