Feature: Login functionality of LeafTaps 

Scenario: valid login 

	Given : launch the browser 
	Given : load the url 
	When : enter the userName 
	When : enter the password 
	When : click on the login button 
	Then : it will navigate to the crm/sfa page 
	
	
	
