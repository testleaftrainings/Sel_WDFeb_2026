Feature: Login functionality of LeafTaps 

Scenario: valid login credential 

	When : enter the userName 'demosalesmanager' 
	When : enter the password 'crmsfa' 
	When : click on the login button 
	Then : it will navigate to the crm/sfa page 
	
Scenario: valid login credentials 

	When : enter the userName 'democsr' 
	When : enter the password 'crmsfa' 
	When : click on the login button 
	
	
Scenario: invalid login credential 

	When : enter the userName 'democsr' 
	When : enter the password 'crm' 
	When : click on the login button 
	
	
	