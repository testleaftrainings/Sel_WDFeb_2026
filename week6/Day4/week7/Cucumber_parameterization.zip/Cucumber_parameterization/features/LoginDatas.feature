Feature: Login functionality of LeafTaps application 

Scenario Outline: multiple test datas for login 

	Given : launch the browser 
	Given : load the url 
	When : enter the userName <uName> 
	When : enter the password <pWord> 
	When : click on the login button 
	Then : it will navigate to the crm/sfa page 
	
	Examples: 
	
		|     uName        |  pWord |
		| demosalesmanager | crmsfa |
		|     'democsr'    | 123456 |
		