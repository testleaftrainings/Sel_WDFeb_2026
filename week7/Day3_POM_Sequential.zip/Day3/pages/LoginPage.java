package pages;

import org.openqa.selenium.By;
import base.ProjectSpecificMethod;

public class LoginPage extends ProjectSpecificMethod{
	
	//1.Enter userName
	//2.Enter PassWord
	//3.Click on Login Button
	
	public LoginPage EnterUserName() throws InterruptedException {
		Thread.sleep(3000);
		driver.findElement(By.id("username")).sendKeys("demosalesmanager");
		return this;
	}

	public LoginPage EnterPassWord() {
		driver.findElement(By.id("password")).sendKeys("crmsfa");
		return this;
	}
	
	public HomePage ClickLoginButton() {
		driver.findElement(By.className("decorativeSubmit")).click();
		return new HomePage();
	}
}
