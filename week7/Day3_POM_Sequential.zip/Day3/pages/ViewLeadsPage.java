package pages;

public class ViewLeadsPage {
	
	//Verify the created Lead with the data.

}
