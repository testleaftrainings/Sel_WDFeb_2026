package pages;

public class MyHomePage {
	
	//1.Click on Leads Button

}
