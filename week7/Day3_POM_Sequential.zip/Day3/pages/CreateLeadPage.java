package pages;

public class CreateLeadPage {
	
	//1.Enter the CompanyName
	//2.Enter the FirstName
	//3.Enter the LastName
	//4.Click on createLead button

}
