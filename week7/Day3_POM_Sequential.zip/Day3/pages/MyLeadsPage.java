package pages;

public class MyLeadsPage {
	
	//1.click on CreatLead Button
}
