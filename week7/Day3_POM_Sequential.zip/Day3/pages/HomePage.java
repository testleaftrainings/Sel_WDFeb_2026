package pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethod;

public class HomePage extends ProjectSpecificMethod {

	// 1.Click on CRM/SFA
	// 2.Click on Logout

	public HomePage ClickLogOut() {
		driver.findElement(By.className("decorativeSubmit")).click();
		return this;
	}

	public MyHomePage ClickCrmSfa() {
		driver.findElement(By.linkText("CRM/SFA")).click();
		return new MyHomePage();
	}

}
