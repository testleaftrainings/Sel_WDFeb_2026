package testCases;

import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class Tc_LogOut_001 extends ProjectSpecificMethod {

	@Test
	public void runLogin() throws InterruptedException {
		LoginPage lp = new LoginPage();
		lp.EnterUserName().EnterPassWord().ClickLoginButton().ClickLogOut();
		
	}

}
