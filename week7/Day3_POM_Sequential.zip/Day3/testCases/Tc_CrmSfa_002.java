package testCases;

import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class Tc_CrmSfa_002 extends ProjectSpecificMethod {

	@Test
	public void runCrmSfa() throws InterruptedException {
		LoginPage logOut = new LoginPage();
		logOut.EnterUserName().EnterPassWord().ClickLoginButton().ClickCrmSfa();
	}

}
