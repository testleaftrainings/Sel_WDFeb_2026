package stepDefenition;

import java.time.Duration;

import org.openqa.selenium.By;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDef extends BaseClass {

//	ChromeDriver driver;

	@Given(": launch the browser")
	public void launch_the_browser() {
		/*
		 * ChromeOptions options = new ChromeOptions(); options.addArguments("--guest");
		 * driver = new ChromeDriver(options); driver.manage().window().maximize();
		 */
	}

	@Given(": load the url")
	public void load_the_url() {
	//	System.out.println("nonStatic");
		driver.get("http://leaftaps.com/opentaps/control/main");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}

	@When(": enter the userName {string}")
	public void enter_the_user_name(String uName) {
		driver.findElement(By.id("username")).sendKeys(uName);

	}

	@When(": enter the password {string}")
	public void enter_the_password(String pWord) {
		driver.findElement(By.id("password")).sendKeys(pWord);

	}

	@When(": click on the login button")
	public void click_on_the_login_button() {
		driver.findElement(By.className("decorativeSubmit")).click();

	}

	@Then(": it will navigate to the crm\\/sfa page")
	public void it_will_navigate_to_the_crm_sfa_page() {
		String title = driver.getTitle();
		System.out.println(title);
	}

	@When(": it will not navigate to the crm\\/sfa page")
	public void it_will_not_navigate_to_the_crm_sfa_page() {
		String title = driver.getTitle();
		System.out.println(title);
	}

}
