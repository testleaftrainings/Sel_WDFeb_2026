package hooks;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import stepDefenition.BaseClass;

public class HooksImplementation extends BaseClass{
	
//	public ChromeDriver driver; io.cucumber.java.InvalidMethodException: 
	//You're not allowed to extend classes that define Step Definitions or hooks.

	@Before
	public void preCondition() {

		ChromeOptions options = new ChromeOptions();
		options.addArguments("--guest");
		driver = new ChromeDriver(options);
		driver.manage().window().maximize();

	}

	@After
	public void postCondition() {

		driver.close();
	}

}
