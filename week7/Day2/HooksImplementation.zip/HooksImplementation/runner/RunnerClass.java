package runner;

import io.cucumber.testng.CucumberOptions;
import stepDefenition.BaseClass;

@CucumberOptions(features = "src/main/java/features/Login.feature", glue = {
		"stepDefenition" }, publish = true, tags = "@Vignesh or @Regression or @Smoke")
public class RunnerClass extends BaseClass {

}
